from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False, default='Warden')  # Admin, Warden, Accountant, Student

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Room(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    room_number = db.Column(db.String(50), unique=True, nullable=False)
    room_type = db.Column(db.String(50), nullable=False)  # e.g., 4-seater
    capacity = db.Column(db.Integer, nullable=False)
    occupied_seats = db.Column(db.Integer, default=0)
    is_ac = db.Column(db.Boolean, default=False)
    gender = db.Column(db.String(10), nullable=False)  # Male, Female, Mixed
    students = db.relationship('Student', backref='room', lazy=True)
    complaints = db.relationship('Complaint', backref='room', lazy=True)

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    roll_no = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    gender = db.Column(db.String(10), nullable=False)
    check_in_date = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    parent_contact = db.Column(db.String(20))
    fee_status = db.Column(db.String(20), default='Due')  # Paid, Due, Partial
    room_id = db.Column(db.Integer, db.ForeignKey('room.id'), nullable=True)
    fee_transactions = db.relationship('FeeTransaction', backref='student', lazy=True)
    attendances = db.relationship('Attendance', backref='student', lazy=True)
    complaints = db.relationship('Complaint', backref='student', lazy=True)

class ActivityLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    username = db.Column(db.String(150), nullable=False)
    action_details = db.Column(db.Text, nullable=False)

class FeeTransaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    amount_paid = db.Column(db.Float, nullable=False)
    due_date = db.Column(db.DateTime, nullable=False)
    payment_status = db.Column(db.String(20), default='Due')  # Paid, Due, Partial
    transaction_date = db.Column(db.DateTime, default=datetime.utcnow)

class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    meal_status = db.Column(db.String(20), default='Present')  # Present, Absent

class Complaint(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='New')  # New, In Progress, Resolved
    assigned_to = db.Column(db.String(150))  # Technician name
    room_number = db.Column(db.String(50))
    room_id = db.Column(db.Integer, db.ForeignKey('room.id'), nullable=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Settings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.String(200), nullable=False)

class MessPlan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    plan_name = db.Column(db.String(100), nullable=False)
    duration = db.Column(db.String(50), nullable=False)  # Monthly, Quarterly
    cost = db.Column(db.Float, nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=True)
