// Custom JavaScript for Hostel Management System

$(document).ready(function() {
    // Initialize tooltips
    $('[data-toggle="tooltip"]').tooltip();

    // Confirmation modal for delete actions
    $('.delete-btn').on('click', function(e) {
        e.preventDefault();
        var href = $(this).attr('href');
        $('#confirmDeleteModal').modal('show');
        $('#confirmDeleteBtn').attr('href', href);
    });

    // Form validation
    $('form').on('submit', function(e) {
        var isValid = true;
        $(this).find('input[required], select[required], textarea[required]').each(function() {
            if ($(this).val().trim() === '') {
                $(this).addClass('is-invalid');
                isValid = false;
            } else {
                $(this).removeClass('is-invalid');
            }
        });

        if (!isValid) {
            e.preventDefault();
            alert('Please fill in all required fields.');
        }
    });

    // Real-time form feedback
    $('input, select, textarea').on('blur', function() {
        if ($(this).val().trim() !== '') {
            $(this).removeClass('is-invalid');
        }
    });

    // Animate cards on load
    $('.card').addClass('fade-in');

    // Dynamic room capacity check
    $('#room_id').on('change', function() {
        var selectedOption = $(this).find('option:selected');
        var capacityText = selectedOption.text();
        var occupied = capacityText.match(/\((\d+)\/(\d+)\)/);
        if (occupied) {
            var occupiedSeats = parseInt(occupied[1]);
            var capacity = parseInt(occupied[2]);
            if (occupiedSeats >= capacity) {
                alert('This room is full!');
                $(this).val('');
            }
        }
    });

    // Fee status change confirmation
    $('.fee-status-select').on('change', function() {
        var studentName = $(this).closest('tr').find('td:first').text();
        if (confirm('Change fee status for ' + studentName + '?')) {
            $(this).closest('form').submit();
        } else {
            $(this).val($(this).data('original-value'));
        }
    });

    // Store original values for fee status
    $('.fee-status-select').each(function() {
        $(this).data('original-value', $(this).val());
    });
});
