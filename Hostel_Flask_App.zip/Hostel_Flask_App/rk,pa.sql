-- Create the database
CREATE DATABASE IF NOT EXISTS paras;

-- Use the database
USE paras;

-- Create User table
CREATE TABLE user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(150) UNIQUE NOT NULL,
    password_hash VARCHAR(150) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'Warden'
);

-- Create Room table
CREATE TABLE room (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(50) UNIQUE NOT NULL,
    room_type VARCHAR(50) NOT NULL,
    capacity INT NOT NULL,
    occupied_seats INT DEFAULT 0,
    is_ac BOOLEAN DEFAULT FALSE,
    gender VARCHAR(10) NOT NULL
);

-- Create Student table
CREATE TABLE student (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    roll_no VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    check_in_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    parent_contact VARCHAR(20),
    fee_status VARCHAR(20) DEFAULT 'Due',
    room_id INT,
    FOREIGN KEY (room_id) REFERENCES room(id)
);

-- Create ActivityLog table
CREATE TABLE activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    username VARCHAR(150) NOT NULL,
    action_details TEXT NOT NULL
);

-- Create FeeTransaction table
CREATE TABLE fee_transaction (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    amount_paid FLOAT NOT NULL,
    due_date DATETIME NOT NULL,
    payment_status VARCHAR(20) DEFAULT 'Due',
    transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES student(id)
);

-- Create Attendance table
CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    date DATE NOT NULL,
    meal_status VARCHAR(20) DEFAULT 'Present',
    FOREIGN KEY (student_id) REFERENCES student(id)
);

-- Create Complaint table
CREATE TABLE complaint (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'New',
    assigned_to VARCHAR(150),
    room_number VARCHAR(50),
    room_id INT,
    student_id INT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES room(id),
    FOREIGN KEY (student_id) REFERENCES student(id)
);

-- Create Settings table
CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    key VARCHAR(100) UNIQUE NOT NULL,
    value VARCHAR(200) NOT NULL
);

-- Create MessPlan table
CREATE TABLE mess_plan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    plan_name VARCHAR(100) NOT NULL,
    duration VARCHAR(50) NOT NULL,
    cost FLOAT NOT NULL,
    student_id INT,
    FOREIGN KEY (student_id) REFERENCES student(id)
);

-- Insert sample data

-- Insert admin user (password hash for 'Rocky@123')
INSERT INTO user (username, password_hash, role) VALUES ('Rocky', 'pbkdf2:sha256:600000$example$examplehash', 'Admin');

-- Insert sample rooms
INSERT INTO room (room_number, room_type, capacity, occupied_seats, is_ac, gender) VALUES
('101', '4-seater', 4, 0, TRUE, 'Male'),
('102', '4-seater', 4, 0, FALSE, 'Female'),
('103', '2-seater', 2, 0, TRUE, 'Mixed');

-- Insert sample students
INSERT INTO student (name, roll_no, email, phone, gender, check_in_date, is_active, parent_contact, fee_status, room_id) VALUES
('John Doe', 'CS001', 'john@example.com', '1234567890', 'Male', NOW(), TRUE, '0987654321', 'Paid', 1),
('Jane Smith', 'CS002', 'jane@example.com', '0987654321', 'Female', NOW(), TRUE, '1234567890', 'Due', 2);

-- Insert sample activity log
INSERT INTO activity_log (username, action_details) VALUES ('Rocky', 'System initialized');

-- Insert sample fee transactions
INSERT INTO fee_transaction (student_id, amount_paid, due_date, payment_status, transaction_date) VALUES
(1, 5000.00, '2024-12-31', 'Paid', NOW()),
(2, 0.00, '2024-12-31', 'Due', NOW());

-- Insert sample attendance
INSERT INTO attendance (student_id, date, meal_status) VALUES
(1, CURDATE(), 'Present'),
(2, CURDATE(), 'Absent');

-- Insert sample complaints
INSERT INTO complaint (title, description, status, assigned_to, room_number, room_id, student_id, created_at) VALUES
('Broken Fan', 'The fan in room 101 is not working', 'New', 'Technician A', '101', 1, 1, NOW());

-- Insert sample settings
INSERT INTO settings (key, value) VALUES
('late_fee_amount', '100'),
('academic_year_start', '2024-07-01'),
('hostel_name', 'Paras Hostel');

-- Insert sample mess plans
INSERT INTO mess_plan (plan_name, duration, cost, student_id) VALUES
('Basic Monthly', 'Monthly', 3000.00, 1),
('Premium Quarterly', 'Quarterly', 8000.00, 2);

-- Select queries to view data

-- View all users
SELECT * FROM user;

-- View all rooms
SELECT * FROM room;

-- View all students with room info
SELECT s.*, r.room_number FROM student s LEFT JOIN room r ON s.room_id = r.id;

-- View activity log
SELECT * FROM activity_log;

-- View fee transactions
SELECT ft.*, s.name FROM fee_transaction ft JOIN student s ON ft.student_id = s.id;

-- View attendance
SELECT a.*, s.name FROM attendance a JOIN student s ON a.student_id = s.id;

-- View complaints
SELECT c.*, s.name AS student_name, r.room_number FROM complaint c 
LEFT JOIN student s ON c.student_id = s.id 
LEFT JOIN room r ON c.room_id = r.id;

-- View settings
SELECT * FROM settings;

-- View mess plans
SELECT mp.*, s.name AS student_name FROM mess_plan mp LEFT JOIN student s ON mp.student_id = s.id;

-- Reports

-- Total students
SELECT COUNT(*) AS total_students FROM student WHERE is_active = TRUE;

-- Total rooms
SELECT COUNT(*) AS total_rooms FROM room;

-- Occupancy percentage
SELECT 
    (SUM(occupied_seats) / SUM(capacity)) * 100 AS occupancy_percentage 
FROM room;

-- Students with due fees
SELECT * FROM student WHERE fee_status = 'Due' AND is_active = TRUE;

-- Monthly attendance for current month
SELECT COUNT(*) AS monthly_attendance 
FROM attendance 
WHERE meal_status = 'Present' 
AND MONTH(date) = MONTH(CURDATE()) 
AND YEAR(date) = YEAR(CURDATE());