from flask import Flask, render_template, redirect, url_for, flash, request
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash
from models import db, User, Room, Student, ActivityLog, FeeTransaction, Attendance, Complaint, Settings, MessPlan
import mysql.connector
from mysql.connector import Error
from functools import wraps
from datetime import datetime, date

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Rakesh%402003@localhost/paras'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def role_required(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if current_user.role != role:
                flash('Access denied')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def log_activity(username, action):
    log = ActivityLog(username=username, action_details=action)
    db.session.add(log)
    db.session.commit()

def create_admin():
    admin = User.query.filter_by(username='Rocky').first()
    if not admin:
        admin = User(username='Rocky', role='Admin')
        admin.set_password('Rocky@123')
        db.session.add(admin)
        db.session.commit()

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Invalid username or password')
    return render_template('login.html')

@app.route('/dashboard')
@login_required
def dashboard():
    total_rooms = Room.query.count()
    total_students = Student.query.filter_by(is_active=True).count()
    due_students = Student.query.filter_by(fee_status='Due', is_active=True).count()
    return render_template('dashboard.html', total_rooms=total_rooms, total_students=total_students, due_students=due_students)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/admin/users', methods=['GET', 'POST'])
@login_required
@role_required('Admin')
def admin_users():
    users = User.query.all()
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        user = User(username=username, role=role)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        log_activity(current_user.username, f"Added user '{username}' with role '{role}'")
        flash('User added successfully')
        return redirect(url_for('admin_users'))
    return render_template('admin_users.html', users=users)

@app.route('/admin/users/delete/<int:id>')
@login_required
@role_required('Admin')
def delete_user(id):
    user = User.query.get_or_404(id)
    if user.username == 'Rocky':
        flash('Cannot delete admin user')
        return redirect(url_for('admin_users'))
    db.session.delete(user)
    db.session.commit()
    log_activity(current_user.username, f"Deleted user '{user.username}'")
    flash('User deleted successfully')
    return redirect(url_for('admin_users'))

@app.route('/rooms', methods=['GET', 'POST'])
@login_required
def rooms():
    rooms = Room.query.all()
    if request.method == 'POST':
        room_number = request.form['room_number']
        room_type = request.form['room_type']
        capacity = int(request.form['capacity'])
        is_ac = 'is_ac' in request.form
        gender = request.form['gender']
        room = Room(room_number=room_number, room_type=room_type, capacity=capacity, is_ac=is_ac, gender=gender)
        db.session.add(room)
        db.session.commit()
        flash('Room added successfully')
        return redirect(url_for('rooms'))
    return render_template('rooms.html', rooms=rooms)

@app.route('/rooms/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_room(id):
    room = Room.query.get_or_404(id)
    if request.method == 'POST':
        room.room_number = request.form['room_number']
        room.room_type = request.form['room_type']
        room.capacity = int(request.form['capacity'])
        room.is_ac = 'is_ac' in request.form
        room.gender = request.form['gender']
        db.session.commit()
        flash('Room updated successfully')
        return redirect(url_for('rooms'))
    return render_template('edit_room.html', room=room)

@app.route('/rooms/delete/<int:id>')
@login_required
def delete_room(id):
    room = Room.query.get_or_404(id)
    if room.occupied_seats > 0:
        flash('Cannot delete room with occupied seats')
        return redirect(url_for('rooms'))
    db.session.delete(room)
    db.session.commit()
    flash('Room deleted successfully')
    return redirect(url_for('rooms'))

@app.route('/students', methods=['GET', 'POST'])
@login_required
def students():
    students = Student.query.filter_by(is_active=True).all()
    rooms = Room.query.all()
    if request.method == 'POST':
        name = request.form['name']
        roll_no = request.form['roll_no']
        email = request.form['email']
        phone = request.form['phone']
        gender = request.form['gender']
        parent_contact = request.form.get('parent_contact')
        room_id = request.form.get('room_id')
        if room_id:
            room = Room.query.get(int(room_id))
            if room.occupied_seats >= room.capacity:
                flash('Room is full')
                return redirect(url_for('students'))
            if room.gender != 'Mixed' and room.gender != gender:
                flash('Gender mismatch')
                return redirect(url_for('students'))
            room.occupied_seats += 1
        student = Student(name=name, roll_no=roll_no, email=email, phone=phone, gender=gender, parent_contact=parent_contact, room_id=room_id)
        db.session.add(student)
        db.session.commit()
        flash('Student added successfully')
        return redirect(url_for('students'))
    return render_template('students.html', students=students, rooms=rooms)

@app.route('/students/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_student(id):
    student = Student.query.get_or_404(id)
    rooms = Room.query.all()
    if request.method == 'POST':
        old_room_id = student.room_id
        student.name = request.form['name']
        student.roll_no = request.form['roll_no']
        student.email = request.form['email']
        student.phone = request.form['phone']
        student.gender = request.form['gender']
        student.parent_contact = request.form.get('parent_contact')
        new_room_id = request.form.get('room_id')
        if new_room_id != old_room_id:
            if old_room_id:
                old_room = Room.query.get(int(old_room_id))
                old_room.occupied_seats -= 1
            if new_room_id:
                new_room = Room.query.get(int(new_room_id))
                if new_room.occupied_seats >= new_room.capacity:
                    flash('Room is full')
                    return redirect(url_for('edit_student', id=id))
                if new_room.gender != 'Mixed' and new_room.gender != student.gender:
                    flash('Gender mismatch')
                    return redirect(url_for('edit_student', id=id))
                new_room.occupied_seats += 1
        student.room_id = new_room_id
        db.session.commit()
        flash('Student updated successfully')
        return redirect(url_for('students'))
    return render_template('edit_student.html', student=student, rooms=rooms)

@app.route('/students/delete/<int:id>')
@login_required
def delete_student(id):
    student = Student.query.get_or_404(id)
    if student.room_id:
        room = Room.query.get(student.room_id)
        room.occupied_seats -= 1
    student.is_active = False
    db.session.commit()
    log_activity(current_user.username, f"Checked out student '{student.name}' (Roll: {student.roll_no})")
    flash('Student checked out successfully')
    return redirect(url_for('students'))

@app.route('/students/fee/<int:id>', methods=['POST'])
@login_required
def update_fee(id):
    student = Student.query.get_or_404(id)
    old_status = student.fee_status
    student.fee_status = request.form['fee_status']
    db.session.commit()
    log_activity(current_user.username, f"Updated fee status for student '{student.name}' from '{old_status}' to '{student.fee_status}'")
    flash('Fee status updated')
    return redirect(url_for('students'))

@app.route('/reports')
@login_required
def reports():
    total_students = Student.query.filter_by(is_active=True).count()
    total_rooms = Room.query.count()
    total_capacity = db.session.query(db.func.sum(Room.capacity)).scalar() or 0
    occupied_seats = db.session.query(db.func.sum(Room.occupied_seats)).scalar() or 0
    occupancy_percentage = (occupied_seats / total_capacity * 100) if total_capacity > 0 else 0
    due_students = Student.query.filter_by(fee_status='Due', is_active=True).count()
    # New: Fee due students list
    fee_due_students = Student.query.filter_by(fee_status='Due', is_active=True).all()
    # New: Monthly attendance (placeholder for selected month, using current month)
    from datetime import datetime
    current_month = datetime.now().month
    current_year = datetime.now().year
    monthly_attendance = db.session.query(db.func.sum(Attendance.meal_status == 'Present')).filter(
        db.extract('month', Attendance.date) == current_month,
        db.extract('year', Attendance.date) == current_year
    ).scalar() or 0
    return render_template('reports.html', total_students=total_students, total_rooms=total_rooms, occupancy_percentage=round(occupancy_percentage, 2), due_students=due_students, fee_due_students=fee_due_students, monthly_attendance=monthly_attendance)

@app.route('/mess_attendance', methods=['GET', 'POST'])
@login_required
def mess_attendance():
    if request.method == 'POST':
        student_id = int(request.form['student_id'])
        date_str = request.form['date']
        meal_status = request.form['meal_status']
        # Check if attendance already exists for this student on this date
        existing_attendance = Attendance.query.filter_by(student_id=student_id, date=datetime.fromisoformat(date_str).date()).first()
        if existing_attendance:
            existing_attendance.meal_status = meal_status
            flash('Attendance updated successfully')
        else:
            attendance = Attendance(student_id=student_id, date=datetime.fromisoformat(date_str).date(), meal_status=meal_status)
            db.session.add(attendance)
            flash('Attendance marked successfully')
        db.session.commit()
        log_activity(current_user.username, f"Marked attendance for student ID {student_id} on {date_str}: {meal_status}")
        return redirect(url_for('mess_attendance'))
    students = Student.query.filter_by(is_active=True).all()
    # Calculate monthly attendance
    current_month = datetime.now().month
    current_year = datetime.now().year
    monthly_attendance = db.session.query(db.func.count(Attendance.id)).filter(
        db.extract('month', Attendance.date) == current_month,
        db.extract('year', Attendance.date) == current_year,
        Attendance.meal_status == 'Present'
    ).scalar() or 0
    return render_template('mess_attendance.html', students=students, monthly_attendance=monthly_attendance)

@app.route('/maintenance', methods=['GET', 'POST'])
@login_required
def maintenance():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        room_number = request.form['room_number']
        assigned_to = request.form.get('assigned_to')
        complaint = Complaint(title=title, description=description, room_number=room_number, assigned_to=assigned_to)
        db.session.add(complaint)
        db.session.commit()
        log_activity(current_user.username, f"Logged complaint: {title}")
        flash('Complaint logged successfully')
        return redirect(url_for('maintenance'))
    complaints = Complaint.query.all()
    return render_template('maintenance.html', complaints=complaints)

@app.route('/maintenance/update/<int:id>', methods=['POST'])
@login_required
def update_complaint(id):
    complaint = Complaint.query.get_or_404(id)
    complaint.status = request.form['status']
    complaint.assigned_to = request.form.get('assigned_to')
    db.session.commit()
    log_activity(current_user.username, f"Updated complaint '{complaint.title}' to status '{complaint.status}'")
    flash('Complaint updated successfully')
    return redirect(url_for('maintenance'))

@app.route('/settings', methods=['GET', 'POST'])
@login_required
@role_required('Admin')
def settings():
    if request.method == 'POST':
        key = request.form['key']
        value = request.form['value']
        setting = Settings.query.filter_by(key=key).first()
        if setting:
            setting.value = value
        else:
            setting = Settings(key=key, value=value)
            db.session.add(setting)
        db.session.commit()
        log_activity(current_user.username, f"Updated setting '{key}' to '{value}'")
        flash('Setting updated successfully')
        return redirect(url_for('settings'))
    settings_list = Settings.query.all()
    return render_template('settings.html', settings=settings_list)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        create_admin()
    app.run(debug=True)
